<?php
return [
    'round'=>57,
    'course'=>'WDPF'
];