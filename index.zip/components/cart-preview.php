<?php
// cart-preview.php
// session_start();
// if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
//     echo "<p>Your cart is empty.</p>";
//     return;
// }

// foreach ($_SESSION['cart'] as $item) {
//     echo "<div class='mb-2 border-bottom pb-2'>";
//     echo "<strong>{$item['name']}</strong><br>";
//     echo "Qty: {$item['qty']} | Price: ৳{$item['price']}<br>";
//     echo "</div>";
// }
// ?>
